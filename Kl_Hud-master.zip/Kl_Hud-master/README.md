# Kl_Hud
Kl_Hud
Para instalar el hud teneis que cambiar un tigger en el esx_status
que se llama TriggerEvent('esx_status:onTick', GetStatusData(true)) o parecido y poner : TriggerEvent('Kl_Hud:onTick', GetStatusData(true))
Con todo eso ya estaria
